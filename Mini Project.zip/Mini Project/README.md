# DWM_mini_project
 Data Warehouse and Mining Project to show the dataset analysis using Regression Alogrithm in Machine Learning


Steps:
1. Open the main.py file in the final_codes_neede  folder
2. Download the required python libraries
3. Upload any .csv dataset, just make sure that the variable to be predicted is the last column of the dataset
4. Upload the file in the UI
5. The result will give the data anaysis of the dataset, its accuracy, and the result graphs.

  
